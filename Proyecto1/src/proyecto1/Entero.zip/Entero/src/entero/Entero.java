/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entero;

public class Entero {

   private String parImpar(int nume) {
        
       if (nume % 2 == 0) {
            return "par";
        } else {
            return "impar";
        }
    }
 public static void main(String[] args) {
 
    Entero objeto = new Entero();
    System.out.println(objeto.parImpar(6));
    System.out.println(objeto.parImpar(3));
    //System.out.println(objeto.parImpar(3.1);
    //System.out.println(objeto.parImpar("a"); 
    System.out.println(objeto.parImpar('a'));
    System.out.println(objeto.parImpar((int)5.1));
    
 }
    
}
